from setuptools import setup, find_packages

setup(
	name='spiderRobot',
	version='0.1',
	description='module to interface with hardware controls on robot platform',
	author='Bejec',
	author_email='bejecreimer@gmail.com',
	packages=find_packages(),
)
