# Spider Robot 18DOF
Hardware Platform (Not sponsored): https://www.hiwonder.hk/collections/multi-legged-robot/products/robosoul-spiderpi-ai-intelligent-visual-hexapod-robot-powered-by-raspberry-pi
